﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InfotechSolution
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DO6EB3C\SQLEXPRESS;Initial Catalog=LoginData;Integrated Security=True");
        private void Clear()
        {
            Nametxt.Text = "";
            Emailtxt.Text = "";
            Phonetxt.Text = "";
            MaleRadio.Checked = MaleRadio.Enabled;
            FemalRadio.Checked = FemalRadio.Enabled;
            DeptBoxtxt.Text = "";
        }

        //Form1 call = new Form1();
        private void Submitbtn_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand command = new SqlCommand("insert into UserTbl (Name,Email,Phone,Gender,Department) values(@N,@E,@P,@G,@D)", con);
                command.Parameters.AddWithValue("@N", Nametxt.Text);
                command.Parameters.AddWithValue("@E", Emailtxt.Text);
                command.Parameters.AddWithValue("@P", Phonetxt.Text);
                command.Parameters.AddWithValue("@G", GetRadioValues());
                command.Parameters.AddWithValue("@D", DeptBoxtxt.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("The Data Successfully Added");
                con.Close();
                Clear();
                this.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private string GetRadioValues()
        {
            if (MaleRadio.Checked) return "Male";
            else return "Female";
        }
    }
}
