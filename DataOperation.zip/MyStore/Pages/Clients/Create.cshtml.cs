using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients
{
    public class CreateModel : PageModel
    {
        public ClientInfo clientiInfo=new ClientInfo();
        public string errorMessage="";
        public string successMessage = "";
        public void OnGet()
        {
        }
        public void OnPost()
        {
            clientiInfo.name = Request.Form["name"];
            clientiInfo.email = Request.Form["email"];
            clientiInfo.phone = Request.Form["phone"];

            if(clientiInfo.name.Length==0|| clientiInfo.email.Length==0||clientiInfo.phone.Length==0)
            {
                errorMessage = "All The Fields are Requied *";
                return;
            }

            //to save the message in the post request we use get success mesage
            try
            {
                String connectionString = "Data Source=DESKTOP-DO6EB3C\\SQLEXPRESS;Initial Catalog=LoginData;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "INSERT INTO clients "+
                                "(name, email, phone) Values "+
                                "(@name, @email, @phone);";

                    using (SqlCommand command=new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", clientiInfo.name);
                        command.Parameters.AddWithValue("@email", clientiInfo.email);
                        command.Parameters.AddWithValue("@phone", clientiInfo.phone);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch(Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            clientiInfo.name = ""; clientiInfo.email = ""; clientiInfo.phone = "";
            successMessage = "New Client Successfully Added";

            //Here we use this for redirect to the Index page here,,
            Response.Redirect("/Clients/Index");
        }
    }
}
