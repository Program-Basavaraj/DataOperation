using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients
{
    public class EditModel : PageModel
    {
        public ClientInfo clientiInfo = new ClientInfo();
        public string errorMessage = "";
        public string successMessage = "";

        public void OnGet()
        {
            String id = Request.Query["id"];
            try
            {
                String connectionString = "Data Source=DESKTOP-DO6EB3C\\SQLEXPRESS;Initial Catalog=LoginData;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM clients WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                //ClientInfo clientinfo = new ClientInfo();
                                clientiInfo.id = "" + reader.GetInt32(0);
                                clientiInfo.name = reader.GetString(1);
                                clientiInfo.email = reader.GetString(2);
                                clientiInfo.phone =  reader.GetString(3);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                errorMessage = ex.Message;
            }
        }
        public void OnPost()
        {
            clientiInfo.id = Request.Form["id"];
            clientiInfo.name = Request.Form["name"];
            clientiInfo.email = Request.Form["email"];
            clientiInfo.phone = Request.Form["phone"];

            if (clientiInfo.name.Length == 0 || clientiInfo.email.Length == 0 || clientiInfo.phone.Length == 0)
            {
                errorMessage = "All The Fields are Requied *";
                return;
            }
            try
            {
                String connectionString = "Data Source=DESKTOP-DO6EB3C\\SQLEXPRESS;Initial Catalog=LoginData;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE clients " +
                                "SET name=@name, email=@email, phone=@phone " +
                                "WHERE id=@id";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", clientiInfo.name);
                        command.Parameters.AddWithValue("@email", clientiInfo.email);
                        command.Parameters.AddWithValue("@phone", clientiInfo.phone);
                        command.Parameters.AddWithValue("@id", clientiInfo.id);

                        command.ExecuteNonQuery(); 
                    }
                }
            }
            catch(Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            Response.Redirect("/Clients/Index");
        }
    }
}
