using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyStore.Pages.Clients
{
    public class IndexModel : PageModel
    {
        public List<ClientInfo> listClients = new List<ClientInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-DO6EB3C\\SQLEXPRESS;Initial Catalog=LoginData;Integrated Security=True";
                using (SqlConnection connection=new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM clients";
                    using (SqlCommand commend=new SqlCommand(sql,connection))
                    {
                        using (SqlDataReader reader=commend.ExecuteReader())
                        {
                            while(reader.Read())
                            {
                                ClientInfo clientinfo = new ClientInfo();
                                clientinfo.id = "" + reader.GetInt32(0);
                                clientinfo.name = "" + reader.GetString(1);
                                clientinfo.email= "" + reader.GetString(2);
                                clientinfo.phone= "" + reader.GetString(3);

                                listClients.Add(clientinfo);
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }
    }
    public class ClientInfo
    {
        public String id;
        public String name;
        public String email;
        public String phone;
    }
}
